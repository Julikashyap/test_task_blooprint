from django.apps import AppConfig


class TesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tes_app'
